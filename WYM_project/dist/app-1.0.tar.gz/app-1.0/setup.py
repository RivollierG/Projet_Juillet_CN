# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['BDD', 'model']

package_data = \
{'': ['*']}

install_requires = \
['Flask>=2.1.2,<3.0.0',
 'SQLAlchemy>=1.4.39,<2.0.0',
 'psycopg2-binary>=2.9.3,<3.0.0',
 'requests>=2.28.1,<3.0.0']

entry_points = \
{'console_scripts': ['siteweb = app.application:main']}

setup_kwargs = {
    'name': 'app',
    'version': '1.0',
    'description': '',
    'long_description': None,
    'author': 'Renaud Crosset',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
