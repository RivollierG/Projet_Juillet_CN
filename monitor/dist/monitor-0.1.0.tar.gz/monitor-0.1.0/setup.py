# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['monitor']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=9.2.0,<10.0.0',
 'SQLAlchemy-Utils>=0.38.2,<0.39.0',
 'SQLAlchemy>=1.4.39,<2.0.0',
 'psycopg2-binary>=2.9.3,<3.0.0',
 'streamlit>=1.10.0,<2.0.0']

entry_points = \
{'console_scripts': ['monitor = monitor.monitoring:main']}

setup_kwargs = {
    'name': 'monitor',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'G. Rivollier',
    'author_email': 'rivollier.g@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
